package university.management.system;
import java.util.ArrayList;
public class Department {
    private String id;
    private String name;
    private ArrayList<String> facultyIds;
    private ArrayList<String> offeredCourses;

    public Department(String id, String name) {
        this.id = id;
        this.name = name;
        this.facultyIds = new ArrayList<String>();
        this.offeredCourses = new ArrayList<String>();
    }

    public String getId() {
        return id;
    }
    public String getName() {
        return name;
    }
    public void addFaculty(String facultyId) {
        if (!facultyIds.contains(facultyId)) {
            facultyIds.add(facultyId);
        }
    }
    public void removeFaculty(String facultyId) {
        facultyIds.remove(facultyId);
    }
    public void addCourse(String courseCode) {
        if (!offeredCourses.contains(courseCode)) {
            offeredCourses.add(courseCode);
        }
    }
    public void removeCourse(String courseCode) {
        offeredCourses.remove(courseCode);
    }
    public ArrayList<String> getFacultyIds() {
        return facultyIds;
    }
    public ArrayList<String> getOfferedCourses() {
        return offeredCourses;
    }
}