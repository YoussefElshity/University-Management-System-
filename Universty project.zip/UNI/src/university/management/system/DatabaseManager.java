package university.management.system;
import java.io.*;
import java.sql.*;
import java.util.*;
public class DatabaseManager {
    private static final String DB_URL = "jdbc:sqlite:university.db";

    static {
        try {
            Class.forName("org.sqlite.JDBC");
        } catch (ClassNotFoundException ex) {
            System.out.println("SQLite JDBC driver not found on classpath: " + ex.getMessage());
        }
    }

    private static Connection openConnection() throws SQLException {
        Connection conn = DriverManager.getConnection(DB_URL);
        try (Statement st = conn.createStatement()) {
            st.execute("PRAGMA foreign_keys = ON;");
            st.execute("PRAGMA busy_timeout = 5000;");
        }
        return conn;
    }

    public static void initDatabase() {
        String createUsers = "CREATE TABLE IF NOT EXISTS users ("
                + "id TEXT PRIMARY KEY, role TEXT, username TEXT UNIQUE, passwordHash TEXT, salt TEXT, name TEXT, email TEXT,"
                + "admissionDate TEXT, academicStatus TEXT, department TEXT, expertise TEXT, staffRole TEXT, securityLevel TEXT"
                + ");";
        String createCourses =
                "CREATE TABLE IF NOT EXISTS courses ("
                        + "code TEXT PRIMARY KEY, title TEXT, description TEXT, creditHours REAL, maxEnrollment INTEGER, prereqCsv TEXT, instructorId TEXT, schedule TEXT,"
                        + "FOREIGN KEY(instructorId) REFERENCES users(id) ON DELETE SET NULL ON UPDATE CASCADE"
                        + ");";
        String createDepartments = "CREATE TABLE IF NOT EXISTS departments (id TEXT PRIMARY KEY, name TEXT, facultyCsv TEXT, coursesCsv TEXT);";
        String createEnrollments =
                "CREATE TABLE IF NOT EXISTS enrollments ("
                        + "id INTEGER PRIMARY KEY AUTOINCREMENT, studentId TEXT, courseCode TEXT, enrollmentDate TEXT, grade REAL, status TEXT,"
                        + "FOREIGN KEY(studentId) REFERENCES users(id) ON DELETE CASCADE ON UPDATE CASCADE,"
                        + "FOREIGN KEY(courseCode) REFERENCES courses(code) ON DELETE CASCADE ON UPDATE CASCADE"
                        + ");";

        try (Connection conn = openConnection();
             Statement st = conn.createStatement()) {
            st.execute(createUsers);
            st.execute(createCourses);
            st.execute(createDepartments);
            st.execute(createEnrollments);
        } catch (SQLException ex) {
            System.out.println("DB init error: " + ex.getMessage());
        }
    }

    public static void saveAll(University uni) {
        initDatabase();
        try (Connection conn = openConnection()) {
            conn.setAutoCommit(false);
            try (Statement st = conn.createStatement()) {
                st.executeUpdate("DELETE FROM enrollments;");
                st.executeUpdate("DELETE FROM users;");
                st.executeUpdate("DELETE FROM courses;");
                st.executeUpdate("DELETE FROM departments;");
            }

            String userSql = "INSERT INTO users(id, role, username, passwordHash, salt, name, email, admissionDate, academicStatus, department, expertise, staffRole, securityLevel) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?);";
            try (PreparedStatement ps = conn.prepareStatement(userSql)) {
                for (User u : uni.getUsers()) {
                    ps.setString(1, u.getId());
                    ps.setString(2, u.getRole());
                    ps.setString(3, u.getUsername());
                    ps.setString(4, u.getPasswordHash());
                    ps.setString(5, u.getSalt());
                    ps.setString(6, u.getName());
                    ps.setString(7, u.getEmail());
                    if (u instanceof Student) {
                        Student s = (Student) u;
                        ps.setString(8, s.getAdmissionDate());
                        ps.setString(9, s.getAcademicStatus());
                        ps.setString(10, null); ps.setString(11, null); ps.setString(12, null); ps.setString(13, null);
                    } else if (u instanceof Faculty) {
                        Faculty f = (Faculty) u;
                        ps.setString(8, null); ps.setString(9, null); ps.setString(10, f.getDepartment()); ps.setString(11, f.getExpertise()); ps.setString(12, null); ps.setString(13, null);
                    } else if (u instanceof AdminStaff) {
                        AdminStaff a = (AdminStaff) u;
                        ps.setString(8, null); ps.setString(9, null); ps.setString(10, a.getDepartment()); ps.setString(11, null); ps.setString(12, a.getStaffRole()); ps.setString(13, null);
                    } else if (u instanceof SystemAdmin) {
                        SystemAdmin sa = (SystemAdmin) u;
                        ps.setString(8, null); ps.setString(9, null); ps.setString(10, null); ps.setString(11, null); ps.setString(12, null); ps.setString(13, sa.getSecurityLevel());
                    } else {
                        ps.setString(8, null); ps.setString(9, null); ps.setString(10, null); ps.setString(11, null); ps.setString(12, null); ps.setString(13, null);
                    }
                    ps.addBatch();
                }
                ps.executeBatch();
            }

            String courseSql = "INSERT INTO courses(code, title, description, creditHours, maxEnrollment, prereqCsv, instructorId, schedule) VALUES (?,?,?,?,?,?,?,?);";
            try (PreparedStatement ps = conn.prepareStatement(courseSql)) {
                for (Course c : uni.getCourses()) {
                    ps.setString(1, c.getCode());
                    ps.setString(2, c.getTitle());
                    ps.setString(3, c.getDescription());
                    ps.setDouble(4, c.getCreditHours());
                    ps.setInt(5, c.getMaxEnrollment());
                    ps.setString(6, String.join(",", c.getPrerequisites()));
                    ps.setString(7, c.getInstructorId());
                    ps.setString(8, c.getSchedule());
                    ps.addBatch();
                }
                ps.executeBatch();
            }

            String deptSql = "INSERT INTO departments(id, name, facultyCsv, coursesCsv) VALUES (?,?,?,?);";
            try (PreparedStatement ps = conn.prepareStatement(deptSql)) {
                for (Department d : uni.getDepartments()) {
                    ps.setString(1, d.getId());
                    ps.setString(2, d.getName());
                    ps.setString(3, String.join(",", d.getFacultyIds()));
                    ps.setString(4, String.join(",", d.getOfferedCourses()));
                    ps.addBatch();
                }
                ps.executeBatch();
            }

            String enSql = "INSERT INTO enrollments(studentId, courseCode, enrollmentDate, grade, status) VALUES (?,?,?,?,?);";
            try (PreparedStatement ps = conn.prepareStatement(enSql)) {
                for (Enrollment e : uni.getEnrollments()) {
                    ps.setString(1, e.getStudentId());
                    ps.setString(2, e.getCourseCode());
                    ps.setString(3, e.getEnrollmentDate());
                    ps.setDouble(4, e.getGrade());
                    ps.setString(5, e.getStatus());
                    ps.addBatch();
                }
                ps.executeBatch();
            }

            conn.commit();
        } catch (SQLException ex) {
            System.out.println("DB saveAll error: " + ex.getMessage());
        }
    }
    public static boolean insertCourse(Course c) {
        initDatabase();
        String sql = "INSERT INTO courses(code, title, description, creditHours, maxEnrollment, prereqCsv, instructorId, schedule) VALUES (?,?,?,?,?,?,?,?);";
        try (Connection conn = openConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, c.getCode());
            ps.setString(2, c.getTitle());
            ps.setString(3, c.getDescription());
            ps.setDouble(4, c.getCreditHours());
            ps.setInt(5, c.getMaxEnrollment());
            ps.setString(6, String.join(",", c.getPrerequisites()));
            ps.setString(7, c.getInstructorId());
            ps.setString(8, c.getSchedule());
            ps.executeUpdate();
            return true;
        } catch (SQLException ex) {
            System.out.println("insertCourse error: " + ex.getMessage());
            return false;
        }
    }

    public static boolean updateCourse(Course c) {
        initDatabase();
        String sql = "UPDATE courses SET title=?, description=?, creditHours=?, maxEnrollment=?, prereqCsv=?, instructorId=?, schedule=? WHERE code=?;";
        try (Connection conn = openConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, c.getTitle());
            ps.setString(2, c.getDescription());
            ps.setDouble(3, c.getCreditHours());
            ps.setInt(4, c.getMaxEnrollment());
            ps.setString(5, String.join(",", c.getPrerequisites()));
            ps.setString(6, c.getInstructorId());
            ps.setString(7, c.getSchedule());
            ps.setString(8, c.getCode());
            int updated = ps.executeUpdate();
            return updated > 0;
        } catch (SQLException ex) {
            System.out.println("updateCourse error: " + ex.getMessage());
            return false;
        }
    }

    public static boolean deleteCourse(String code) {
        initDatabase();
        String sql = "DELETE FROM courses WHERE code = ?;";
        try (Connection conn = openConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, code);
            int deleted = ps.executeUpdate();
            return deleted > 0;
        } catch (SQLException ex) {
            System.out.println("deleteCourse error: " + ex.getMessage());
            return false;
        }
    }

    public static boolean deleteUser(String userId) {
        initDatabase();
        String sql = "DELETE FROM users WHERE id = ?;";
        try (Connection conn = openConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, userId);
            int deleted = ps.executeUpdate();
            return deleted > 0;
        } catch (SQLException ex) {
            System.out.println("deleteUser error: " + ex.getMessage());
            return false;
        }
    }

    public static boolean updateEnrollmentGrade(String studentId, String courseCode, double grade, String status) {
        initDatabase();
        String sql = "UPDATE enrollments SET grade=?, status=? WHERE studentId=? AND courseCode=? AND status='Registered';";
        try (Connection conn = openConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setDouble(1, grade);
            ps.setString(2, status);
            ps.setString(3, studentId);
            ps.setString(4, courseCode);
            int updated = ps.executeUpdate();
            return updated > 0;
        } catch (SQLException ex) {
            System.out.println("updateEnrollmentGrade error: " + ex.getMessage());
            return false;
        }
    }
    public static void loadAll(University uni) {
        initDatabase();
        uni.getUsers().clear();
        uni.getStudents().clear();
        uni.getFaculties().clear();
        uni.getAdminStaffs().clear();
        uni.getSystemAdmins().clear();
        uni.getCourses().clear();
        uni.getDepartments().clear();
        uni.getEnrollments().clear();

        try (Connection conn = openConnection()) {
            String qUsers = "SELECT * FROM users;";
            try (PreparedStatement ps = conn.prepareStatement(qUsers);
                 ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    String role = rs.getString("role");
                    String id = rs.getString("id");
                    String username = rs.getString("username");
                    String passwordHash = rs.getString("passwordHash");
                    String salt = rs.getString("salt");
                    String name = rs.getString("name");
                    String email = rs.getString("email");
                    if ("Student".equals(role)) {
                        String adm = rs.getString("admissionDate");
                        String status = rs.getString("academicStatus");
                        Student s = new Student(id, name, username, passwordHash, salt, email, adm, status);
                        uni.addStudent(s);
                    } else if ("Faculty".equals(role)) {
                        String dept = rs.getString("department");
                        String exp = rs.getString("expertise");
                        Faculty f = new Faculty(id, name, username, passwordHash, salt, email, dept, exp);
                        uni.addFaculty(f);
                    } else if ("AdminStaff".equals(role)) {
                        String dept = rs.getString("department");
                        String staffRole = rs.getString("staffRole");
                        AdminStaff a = new AdminStaff(id, name, username, passwordHash, salt, email, dept, staffRole);
                        uni.addAdminStaff(a);
                    } else if ("SystemAdmin".equals(role)) {
                        String sec = rs.getString("securityLevel");
                        SystemAdmin sa = new SystemAdmin(id, name, username, passwordHash, salt, email, sec);
                        uni.addSystemAdmin(sa);
                    }
                }
            }

            String qCourses = "SELECT * FROM courses;";
            try (PreparedStatement ps = conn.prepareStatement(qCourses);
                 ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    String code = rs.getString("code");
                    String title = rs.getString("title");
                    String desc = rs.getString("description");
                    double credits = rs.getDouble("creditHours");
                    int max = rs.getInt("maxEnrollment");
                    String prereqCsv = rs.getString("prereqCsv");
                    String instr = rs.getString("instructorId");
                    String sched = rs.getString("schedule");
                    Course c = new Course(code, title, desc, credits, prereqCsv, instr, max, sched);
                    uni.addCourse(c);
                }
            }

            String qDeps = "SELECT * FROM departments;";
            try (PreparedStatement ps = conn.prepareStatement(qDeps);
                 ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    String id = rs.getString("id");
                    String name = rs.getString("name");
                    Department d = new Department(id, name);
                    String facCsv = rs.getString("facultyCsv");
                    if (facCsv != null && !facCsv.trim().isEmpty()) {
                        String[] fids = facCsv.split(",");
                        for (String fid : fids) d.addFaculty(fid.trim());
                    }
                    String courseCsv = rs.getString("coursesCsv");
                    if (courseCsv != null && !courseCsv.trim().isEmpty()) {
                        String[] ccs = courseCsv.split(",");
                        for (String cc : ccs) d.addCourse(cc.trim());
                    }
                    uni.addDepartment(d);
                }
            }

            String qEn = "SELECT studentId, courseCode, enrollmentDate, grade, status FROM enrollments;";
            try (PreparedStatement ps = conn.prepareStatement(qEn);
                 ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    String sid = rs.getString("studentId");
                    String ccode = rs.getString("courseCode");
                    String date = rs.getString("enrollmentDate");
                    double grade = rs.getDouble("grade");
                    String status = rs.getString("status");
                    Enrollment e = new Enrollment(sid, ccode, date, grade, status);
                    uni.addEnrollment(e);
                    Student st = uni.findStudentById(sid);
                    if (st != null && ("Registered".equals(status) || "Completed".equals(status))) {
                        if (!st.getEnrolledCourses().contains(ccode)) st.addCourse(ccode);
                    }
                }
            }

        } catch (SQLException ex) {
            System.out.println("DB loadAll error: " + ex.getMessage());
        }
    }
    private static String escapeCsv(String s) {
        if (s == null) return "";
        if (s.contains(",") || s.contains("\"") || s.contains("\n")) {
            return "\"" + s.replace("\"", "\"\"") + "\"";
        } else {
            return s;
        }
    }
    private static ArrayList<String> parseCsvLine(String line) {
        ArrayList<String> out = new ArrayList<>();
        if (line == null)
            return out;
        StringBuilder cur = new StringBuilder();
        boolean inQuotes = false;
        for (int i = 0; i < line.length(); i++) {
            char ch = line.charAt(i);
            if (inQuotes) {
                if (ch == '"') {
                    if (i + 1 < line.length() && line.charAt(i + 1) == '"') {
                        cur.append('"'); i++;
                    } else {
                        inQuotes = false;
                    }
                } else {
                    cur.append(ch);
                }
            } else {
                if (ch == '"') {
                    inQuotes = true;
                } else if (ch == ',') {
                    out.add(cur.toString());
                    cur.setLength(0);
                } else {
                    cur.append(ch);
                }
            }
        }
        out.add(cur.toString());
        return out;
    }

    public static boolean exportCoursesToCSV(String filepath) {
        initDatabase();
        try (Connection conn = openConnection();
             PreparedStatement ps = conn.prepareStatement("SELECT code,title,description,creditHours,prereqCsv,instructorId,maxEnrollment,schedule FROM courses;");
             ResultSet rs = ps.executeQuery();
             BufferedWriter bw = new BufferedWriter(new FileWriter(filepath))) {

            bw.write("code,title,description,creditHours,prereqCsv,instructorId,maxEnrollment,schedule");
            bw.newLine();
            while (rs.next()) {
                String code = rs.getString(1);
                String title = rs.getString(2);
                String desc = rs.getString(3);
                double credits = rs.getDouble(4);
                String prereq = rs.getString(5);
                String instr = rs.getString(6);
                int max = rs.getInt(7);
                String sched = rs.getString(8);

                String line = String.join(",",
                        escapeCsv(code),
                        escapeCsv(title),
                        escapeCsv(desc),
                        escapeCsv(String.valueOf(credits)),
                        escapeCsv(prereq),
                        escapeCsv(instr),
                        escapeCsv(String.valueOf(max)),
                        escapeCsv(sched)
                );
                bw.write(line);
                bw.newLine();
            }
            return true;
        } catch (SQLException | IOException ex) {
            System.out.println("exportCoursesToCSV error: " + ex.getMessage());
            return false;
        }
    }

    public static boolean importCoursesFromCSV(String filepath, boolean overwriteExisting) {
        initDatabase();
        File f = new File(filepath);
        if (!f.exists()) {
            System.out.println("importCoursesFromCSV: file not found: " + filepath);
            return false;
        }
        try (Connection conn = openConnection();
             BufferedReader br = new BufferedReader(new FileReader(f))) {
            conn.setAutoCommit(false);

            String header = br.readLine();
            String line;

            String insertSql = "INSERT INTO courses(code, title, description, creditHours, maxEnrollment, prereqCsv, instructorId, schedule) VALUES (?,?,?,?,?,?,?,?);";
            String updateSql = "UPDATE courses SET title=?, description=?, creditHours=?, maxEnrollment=?, prereqCsv=?, instructorId=?, schedule=? WHERE code=?;";
            String existsSql = "SELECT 1 FROM courses WHERE code = ?;";

            try (PreparedStatement psInsert = conn.prepareStatement(insertSql);
                 PreparedStatement psUpdate = conn.prepareStatement(updateSql);
                 PreparedStatement psExists = conn.prepareStatement(existsSql)) {

                while ((line = br.readLine()) != null) {
                    if (line.trim().isEmpty()) continue;
                    List<String> cols = parseCsvLine(line);
                    if (cols.size() < 8) continue;

                    String code = cols.get(0).trim();
                    String title = cols.get(1).trim();
                    String desc = cols.get(2).trim();
                    double credits = 0.0;
                    try { credits = Double.parseDouble(cols.get(3).trim()); } catch (Exception ignored) {}
                    String prereq = cols.get(4).trim();
                    String instr = cols.get(5).trim();
                    int max = 30;
                    try { max = Integer.parseInt(cols.get(6).trim()); } catch (Exception ignored) {}
                    String sched = cols.get(7).trim();

                    boolean exists = false;
                    psExists.setString(1, code);
                    try (ResultSet rs = psExists.executeQuery()) {
                        if (rs.next()) exists = true;
                    }

                    if (exists) {
                        if (overwriteExisting) {
                            psUpdate.setString(1, title);
                            psUpdate.setString(2, desc);
                            psUpdate.setDouble(3, credits);
                            psUpdate.setInt(4, max);
                            psUpdate.setString(5, prereq);
                            psUpdate.setString(6, instr);
                            psUpdate.setString(7, sched);
                            psUpdate.setString(8, code);
                            psUpdate.executeUpdate();
                        } else {
                            continue;
                        }
                    } else {
                        psInsert.setString(1, code);
                        psInsert.setString(2, title);
                        psInsert.setString(3, desc);
                        psInsert.setDouble(4, credits);
                        psInsert.setInt(5, max);
                        psInsert.setString(6, prereq);
                        psInsert.setString(7, instr);
                        psInsert.setString(8, sched);
                        psInsert.executeUpdate();
                    }
                }
            }
            conn.commit();
            return true;
        } catch (SQLException | IOException ex) {
            System.out.println("importCoursesFromCSV error: " + ex.getMessage());
            try {
                Connection c = DriverManager.getConnection(DB_URL);
                c.rollback();
                c.close();
            } catch (Exception ignore) {

            }
            return false;
        }
    }
}