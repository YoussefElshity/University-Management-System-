package university.management.system;
import java.io.*;
public class FileManager {
    public static void saveAll(University uni) {
        try {
            DatabaseManager.saveAll(uni);
        } catch (Exception ex) {
            System.out.println("Warning: DB save failed, falling back to text files: " + ex.getMessage());
        }
        saveUsers(uni);
        saveStudents(uni);
        saveCourses(uni);
        saveEnrollments(uni);
        saveDepartments(uni);
    }
    public static void saveUsers(University uni) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter("users.txt"))) {
            for (int i = 0; i < uni.getUsers().size(); i++) {
                User u = uni.getUsers().get(i);
                String role = u.getRole();
                String line = role + "|" + u.getId() + "|" + u.getUsername() + "|" + u.getPasswordHash() + "|" + u.getSalt() + "|" + u.getName() + "|" + u.getEmail();
                if (role.equals("Student")) {
                    Student s = (Student) u;
                    line += "|" + s.getAdmissionDate() + "|" + s.getAcademicStatus();
                } else if (role.equals("Faculty")) {
                    Faculty f = (Faculty) u;
                    line += "|" + f.getDepartment() + "|" + f.getExpertise();
                } else if (role.equals("AdminStaff")) {
                    AdminStaff a = (AdminStaff) u;
                    line += "|" + a.getDepartment() + "|" + a.getStaffRole();
                } else if (role.equals("SystemAdmin")) {
                    SystemAdmin sa = (SystemAdmin) u;
                    line += "|" + sa.getSecurityLevel();
                }
                bw.write(line);
                bw.newLine();
            }
        } catch (IOException ex) {
            System.out.println("Error saving users: " + ex.getMessage());
        }
    }

    public static void loadAll(University uni) {
        try {
            DatabaseManager.loadAll(uni);
            return;
        } catch (Exception ex) {
            System.out.println("DB load failed, fallback to text files: " + ex.getMessage());
        }
        loadUsers(uni);
        loadCourses(uni);
        loadEnrollments(uni);
        loadDepartments(uni);
    }
    public static void loadUsers(University uni) {
        try (BufferedReader br = new BufferedReader(new FileReader("users.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split("\\|");
                if (parts.length < 7) continue;
                String role = parts[0];
                String id = parts[1];
                String username = parts[2];
                String passwordHash = parts[3];
                String salt = parts[4];
                String name = parts[5];
                String email = parts[6];
                if (role.equals("Student") && parts.length >= 9) {
                    String admission = parts[7];
                    String status = parts[8];
                    Student s = new Student(id, name, username, passwordHash, salt, email, admission, status);
                    uni.addStudent(s);
                } else if (role.equals("Faculty") && parts.length >= 9) {
                    String dept = parts[7];
                    String expertise = parts[8];
                    Faculty f = new Faculty(id, name, username, passwordHash, salt, email, dept, expertise);
                    uni.addFaculty(f);
                } else if (role.equals("AdminStaff") && parts.length >= 9) {
                    String dept = parts[7];
                    String staffRole = parts[8];
                    AdminStaff a = new AdminStaff(id, name, username, passwordHash, salt, email, dept, staffRole);
                    uni.addAdminStaff(a);
                } else if (role.equals("SystemAdmin") && parts.length >= 8) {
                    String sec = parts[7];
                    SystemAdmin sa = new SystemAdmin(id, name, username, passwordHash, salt, email, sec);
                    uni.addSystemAdmin(sa);
                }
            }
        } catch (IOException ex) {
            System.out.println("users.txt not found on load.");
        }
    }

    public static void loadCourses(University uni) {
        try (BufferedReader br = new BufferedReader(new FileReader("courses.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] p = line.split("\\|");
                if (p.length >= 8) {
                    String code = p[0];
                    String title = p[1];
                    String desc = p[2];
                    double credits = Double.parseDouble(p[3]);
                    int max = Integer.parseInt(p[4]);
                    String prereqCsv = p[5];
                    String instructor = p[6];
                    String schedule = p[7];
                    Course c = new Course(code, title, desc, credits, prereqCsv, instructor, max, schedule);
                    uni.addCourse(c);
                }
            }
        } catch (IOException ex) {
            System.out.println("courses.txt not found on load.");
        }
    }
    public static void saveCourses(University uni) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter("courses.txt"))) {
            for (int i = 0; i < uni.getCourses().size(); i++) {
                Course c = uni.getCourses().get(i);
                String prereq = "";
                for (int j = 0; j < c.getPrerequisites().size(); j++) {
                    if (j > 0) prereq += ",";
                    prereq += c.getPrerequisites().get(j);
                }
                String line = c.getCode() + "|" + c.getTitle() + "|" + c.getDescription() + "|" + c.getCreditHours() + "|" + c.getMaxEnrollment() + "|" + prereq + "|" + c.getInstructorId() + "|" + c.getSchedule();
                bw.write(line);
                bw.newLine();
            }
        } catch (IOException ex) {
            System.out.println("Error saving courses: " + ex.getMessage());
        }
    }
    public static void saveStudents(University uni) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter("students.txt"))) {
            for (int i = 0; i < uni.getStudents().size(); i++) {
                Student s = uni.getStudents().get(i);
                String enrolledCsv = "";
                for (int j = 0; j < s.getEnrolledCourses().size(); j++) {
                    if (j > 0) enrolledCsv += ",";
                    enrolledCsv += s.getEnrolledCourses().get(j);
                }
                String line = s.getId() + "|" + s.getName() + "|" + s.getUsername() + "|" + s.getPasswordHash() + "|" + s.getSalt() + "|" + s.getEmail() + "|" + s.getAdmissionDate() + "|" + s.getAcademicStatus() + "|" + enrolledCsv;
                bw.write(line);
                bw.newLine();
            }
        } catch (IOException ex) {
            System.out.println("Error saving students: " + ex.getMessage());
        }
    }

    public static void saveEnrollments(University uni) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter("enrollments.txt"))) {
            for (int i = 0; i < uni.getEnrollments().size(); i++) {
                Enrollment e = uni.getEnrollments().get(i);
                String line = e.getStudentId() + "|" + e.getCourseCode() + "|" + e.getEnrollmentDate() + "|" + e.getGrade() + "|" + e.getStatus();
                bw.write(line);
                bw.newLine();
            }
        } catch (IOException ex) {
            System.out.println("Error saving enrollments: " + ex.getMessage());
        }
    }

    public static void loadEnrollments(University uni) {
        try (BufferedReader br = new BufferedReader(new FileReader("enrollments.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] p = line.split("\\|");
                if (p.length >= 5) {
                    String sid = p[0];
                    String ccode = p[1];
                    String date = p[2];
                    double grade = Double.parseDouble(p[3]);
                    String status = p[4];
                    Enrollment e = new Enrollment(sid, ccode, date, grade, status);
                    uni.addEnrollment(e);
                    if ("Registered".equals(status) || "Completed".equals(status)) {
                        Student st = uni.findStudentById(sid);
                        if (st != null && !st.getEnrolledCourses().contains(ccode)) st.addCourse(ccode);
                    }
                }
            }
        } catch (IOException ex) {
            System.out.println("enrollments.txt not found on load.");
        }
    }

    public static void saveDepartments(University uni) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter("departments.txt"))) {
            for (int i = 0; i < uni.getDepartments().size(); i++) {
                Department d = uni.getDepartments().get(i);
                String facultyCsv = "";
                for (int j = 0; j < d.getFacultyIds().size(); j++) {
                    if (j > 0) facultyCsv += ",";
                    facultyCsv += d.getFacultyIds().get(j);
                }
                String courseCsv = "";
                for (int j = 0; j < d.getOfferedCourses().size(); j++) {
                    if (j > 0) courseCsv += ",";
                    courseCsv += d.getOfferedCourses().get(j);
                }
                String line = d.getId() + "|" + d.getName() + "|" + facultyCsv + "|" + courseCsv;
                bw.write(line);
                bw.newLine();
            }
        } catch (IOException ex) {
            System.out.println("Error saving departments: " + ex.getMessage());
        }
    }

    public static void loadDepartments(University uni) {
        try (BufferedReader br = new BufferedReader(new FileReader("departments.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] p = line.split("\\|");
                if (p.length >= 2) {
                    String id = p[0];
                    String name = p[1];
                    Department d = new Department(id, name);
                    if (p.length >= 3 && !p[2].trim().isEmpty()) {
                        String[] f = p[2].split(",");
                        for (int i = 0; i < f.length; i++) d.addFaculty(f[i].trim());
                    }
                    if (p.length >= 4 && !p[3].trim().isEmpty()) {
                        String[] c = p[3].split(",");
                        for (int i = 0; i < c.length; i++) d.addCourse(c[i].trim());
                    }
                    uni.addDepartment(d);
                }
            }
        } catch (IOException ex) {
            System.out.println("departments.txt not found on load.");
        }
    }
}