package university.management.system;
import java.util.ArrayList;
public class Student extends User {
    private String admissionDate;
    private String academicStatus;
    private ArrayList<String> enrolledCourses;

    public Student(String id, String name, String username, String passwordHash, String salt, String email, String admissionDate, String academicStatus) {
        super(id, name, username, passwordHash, salt, email);
        this.admissionDate = admissionDate;
        this.academicStatus = academicStatus;
        this.enrolledCourses = new ArrayList<String>();
    }

    public void addCourse(String courseCode) {
        if (!enrolledCourses.contains(courseCode)) {
            enrolledCourses.add(courseCode);
        }
    }
    public void removeCourse(String courseCode) {
        enrolledCourses.remove(courseCode);
    }

    public ArrayList<String> getEnrolledCourses() {
        return enrolledCourses;
    }
    public String getAdmissionDate() {
        return admissionDate;
    }
    public String getAcademicStatus() {
        return academicStatus;
    }
    public void setAdmissionDate(String d) {
        this.admissionDate = d;
    }
    public void setAcademicStatus(String s) {
        this.academicStatus = s;
    }
    public double calculateGPA(University uni) {
        double totalPoints = 0.0;
        double totalCredits = 0.0;
        for (int i = 0; i < uni.getEnrollments().size(); i++) {
            Enrollment e = uni.getEnrollments().get(i);
            if (e.getStudentId().equals(this.id) && e.getGrade() >= 0 && "Completed".equals(e.getStatus())) {
                Course c = uni.findCourseByCode(e.getCourseCode());
                if (c != null) {
                    double grade = e.getGrade();
                    double credits = c.getCreditHours();
                    totalPoints += grade * credits;
                    totalCredits += credits;
                }
            }
        }
        if (totalCredits == 0) return 0.0;
        return totalPoints / totalCredits;
    }
    public String getRole() { return "Student"; }
}