package university.management.system;
import java.util.ArrayList;
public class University {
    private ArrayList<User> users;
    private ArrayList<Student> students;
    private ArrayList<Faculty> faculties;
    private ArrayList<AdminStaff> adminStaffs;
    private ArrayList<SystemAdmin> systemAdmins;
    private ArrayList<Course> courses;
    private ArrayList<Department> departments;
    private ArrayList<Enrollment> enrollments;

    public University() {
        users = new ArrayList<User>();
        students = new ArrayList<Student>();
        faculties = new ArrayList<Faculty>();
        adminStaffs = new ArrayList<AdminStaff>();
        systemAdmins = new ArrayList<SystemAdmin>();
        courses = new ArrayList<Course>();
        departments = new ArrayList<Department>();
        enrollments = new ArrayList<Enrollment>();
    }


    public void addStudent(Student s) {
        students.add(s);
        users.add(s);
    }
    public void addFaculty(Faculty f) {
        faculties.add(f);
        users.add(f);
    }
    public void addAdminStaff(AdminStaff a) {
        adminStaffs.add(a);
        users.add(a);
    }
    public void addSystemAdmin(SystemAdmin sa) {
        systemAdmins.add(sa);
        users.add(sa);
    }
    public void addCourse(Course c) {
        courses.add(c);
    }
    public void addDepartment(Department d) {
        departments.add(d);
    }
    public void addEnrollment(Enrollment e) {
        enrollments.add(e);
    }
    public Student findStudentById(String id) {
        for (int i = 0; i < students.size(); i++) {
            Student s = students.get(i);
            if (s.getId().equals(id)) return s;
        }
        return null;
    }
    public Faculty findFacultyById(String id) {
        for (int i = 0; i < faculties.size(); i++) {
            Faculty f = faculties.get(i);
            if (f.getId().equals(id)) return f;
        }
        return null;
    }
    public Course findCourseByCode(String code) {
        if (code == null) return null;
        for (int i = 0; i < courses.size(); i++) {
            Course c = courses.get(i);
            if (c.getCode() != null && c.getCode().trim().equalsIgnoreCase(code.trim())) return c;
        }
        return null;
    }
    public Department findDepartmentById(String id) {
        for (int i = 0; i < departments.size(); i++) {
            Department d = departments.get(i);
            if (d.getId().equals(id)) return d;
        }
        return null;
    }
    public User authenticate(String username, String plaintextPassword) {
        for (int i = 0; i < users.size(); i++) {
            User u = users.get(i);
            if (u.getUsername().equals(username)) {
                if (PasswordUtil.verifyPassword(plaintextPassword, u.getSalt(), u.getPasswordHash())) {
                    return u;
                }
            }
        }
        return null;
    }
    public boolean withdrawStudentFromCourse(String studentId, String courseCode) {
        for (int i = 0; i < enrollments.size(); i++) {
            Enrollment e = enrollments.get(i);
            if (e.getStudentId().equals(studentId) && e.getCourseCode().equals(courseCode) && e.getStatus().equals("Registered")) {
                e.setStatus("Withdrawn");
                Student s = findStudentById(studentId);
                if (s != null) s.removeCourse(courseCode);
                return true;
            }
        }
        return false;
    }
    public String registerStudentForCourse(String studentId, String courseCode, String date) {
        final double PASSING_GRADE = 50.0;

        if (courseCode == null || courseCode.trim().isEmpty()) return "Invalid course code";
        String trimmedCourse = courseCode.trim();

        Student s = findStudentById(studentId);
        Course c = findCourseByCode(trimmedCourse);
        if (s == null)
            return "Student not found";
        if (c == null)
            return "Course not found";

        Enrollment existing = null;
        for (int i = 0; i < enrollments.size(); i++) {
            Enrollment e = enrollments.get(i);
            if (e.getStudentId().equals(studentId) && e.getCourseCode() != null && e.getCourseCode().trim().equalsIgnoreCase(trimmedCourse)) {
                existing = e; break;
            }
        }

        if (existing != null && "Registered".equals(existing.getStatus()))
            return "Already registered";

        for (int i = 0; i < c.getPrerequisites().size(); i++) {
            String pre = c.getPrerequisites().get(i);
            if (pre == null)
                continue;
            pre = pre.trim();
            if (pre.isEmpty())
                continue;

            boolean satisfied = false;
            for (int j = 0; j < enrollments.size(); j++) {
                Enrollment e = enrollments.get(j);
                if (e.getStudentId().equals(studentId) && e.getCourseCode() != null && e.getCourseCode().trim().equalsIgnoreCase(pre)) {
                    if (e.getGrade() >= PASSING_GRADE && "Completed".equals(e.getStatus())) {
                        satisfied = true;
                        break;
                    }
                }
            }
            if (!satisfied)
                return "Prerequisite " + pre + " not satisfied";
        }

        if (!c.hasAvailableSeats(this))
            return "Course is full";

        if (existing != null) {
            existing.setStatus("Registered");
            if (!s.getEnrolledCourses().contains(c.getCode())) s.addCourse(c.getCode());
            return "Registered successfully (from pending)";
        }

        Enrollment en = new Enrollment(studentId, c.getCode(), date, -1.0, "Registered");
        addEnrollment(en);
        s.addCourse(c.getCode());
        return "Registered successfully";
    }
    public ArrayList<User> getUsers() {
        return users;
    }
    public ArrayList<Student> getStudents() {
        return students;
    }
    public ArrayList<Faculty> getFaculties() {
        return faculties;
    }
    public ArrayList<AdminStaff> getAdminStaffs() {
        return adminStaffs;
    }
    public ArrayList<SystemAdmin> getSystemAdmins() {
        return systemAdmins;
    }
    public ArrayList<Course> getCourses() {
        return courses;
    }
    public ArrayList<Department> getDepartments() {
        return departments;
    }
    public ArrayList<Enrollment> getEnrollments() {
        return enrollments;
    }
}