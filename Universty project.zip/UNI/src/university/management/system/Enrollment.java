package university.management.system;

public class Enrollment {
    private String studentId;
    private String courseCode;
    private String enrollmentDate;
    private double grade;
    private String status;

    public Enrollment(String studentId, String courseCode, String enrollmentDate, double grade, String status) {
        this.studentId = studentId;
        this.courseCode = courseCode;
        this.enrollmentDate = enrollmentDate;
        this.grade = grade;
        this.status = status;
    }

    public String getStudentId() {
        return studentId;
    }
    public String getCourseCode() {
        return courseCode;
    }
    public String getEnrollmentDate() {
        return enrollmentDate;
    }
    public double getGrade() {
        return grade;
    }
    public String getStatus() {
        return status;
    }
    public void setGrade(double g) {
        this.grade = g;
    }
    public void setStatus(String s) {
        this.status = s;
    }
}