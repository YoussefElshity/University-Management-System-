package university.management.system;
public class AdminStaff extends User {
    private String department;
    private String role;

    public AdminStaff(String id, String name, String username, String passwordHash, String salt, String email, String department, String role) {
        super(id, name, username, passwordHash, salt, email);
        this.department = department;
        this.role = role;
    }

    public String getDepartment() {
        return department;
    }
    public String getStaffRole() {
        return role;
    }
    public void setDepartment(String d) {
        this.department = d;
    }
    public void setStaffRole(String r) {
        this.role = r;
    }

    public String getRole() {
        return "AdminStaff";
    }
}