package university.management.system;

public class SystemAdmin extends User {
    private String securityLevel;
    public SystemAdmin(String id, String name, String username, String passwordHash, String salt, String email, String securityLevel) {
        super(id, name, username, passwordHash, salt, email);
        this.securityLevel = securityLevel;
    }
    public String getSecurityLevel() { return securityLevel; }
    public void setSecurityLevel(String s) { this.securityLevel = s; }

    public String getRole() { return "SystemAdmin"; }
}