package university.management.system;
import java.util.ArrayList;
public class Course {
    private String code;
    private String title;
    private String description;
    private double creditHours;
    private ArrayList<String> prerequisites;
    private String instructorId;
    private int maxEnrollment;
    private String schedule;

    public Course(String code, String title, String description, double creditHours, String prereqCsv, String instructorId, int maxEnrollment, String schedule) {
        this.code = code;
        this.title = title;
        this.description = description;
        this.creditHours = creditHours;
        this.prerequisites = new ArrayList<String>();
        if (prereqCsv != null && !prereqCsv.trim().isEmpty()) {
            String[] parts = prereqCsv.split(",");
            for (int i = 0; i < parts.length; i++) {
                this.prerequisites.add(parts[i].trim());
            }
        }
        this.instructorId = instructorId;
        this.maxEnrollment = maxEnrollment;
        this.schedule = schedule;
    }
    public String getCode() {
        return code;
    }
    public String getTitle() {
        return title;
    }
    public String getDescription() {
        return description;
    }
    public double getCreditHours() {
        return creditHours;
    }
    public ArrayList<String> getPrerequisites() {
        return prerequisites;
    }
    public String getInstructorId() {
        return instructorId;
    }
    public int getMaxEnrollment() {
        return maxEnrollment;
    }
    public String getSchedule() {
        return schedule;
    }

    public void setInstructorId(String id) {
        this.instructorId = id;
    }
    public void setMaxEnrollment(int m) {
        this.maxEnrollment = m;
    }
    public void setSchedule(String s) {
        this.schedule = s;
    }
    public boolean hasAvailableSeats(University uni) {
        int count = 0;
        for (int i = 0; i < uni.getEnrollments().size(); i++) {
            Enrollment e = uni.getEnrollments().get(i);
            if (e.getCourseCode() != null && e.getCourseCode().trim().equalsIgnoreCase(this.code)) {
                if ("Registered".equals(e.getStatus())) {
                    count++;
                }
            }
        }
        return count < this.maxEnrollment;
    }
}