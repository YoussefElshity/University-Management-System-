package university.management.system;
import java.util.ArrayList;
public class Faculty extends User {
    private String department;
    private String expertise;
    private ArrayList<String> coursesTeaching;

    public Faculty(String id, String name, String username, String passwordHash, String salt, String email, String department, String expertise) {
        super(id, name, username, passwordHash, salt, email);
        this.department = department;
        this.expertise = expertise;
        this.coursesTeaching = new ArrayList<String>();
    }
    public String getDepartment() {
        return department;
    }
    public String getExpertise() {
        return expertise;
    }
    public void addCourseTeaching(String courseCode) {
        if (!coursesTeaching.contains(courseCode)) {
            coursesTeaching.add(courseCode);
        }
    }
    public void removeCourseTeaching(String courseCode) {
        coursesTeaching.remove(courseCode);
    }
    public ArrayList<String> getCoursesTeaching() {
        return coursesTeaching;
    }
    public String getRole() { return "Faculty"; }
}