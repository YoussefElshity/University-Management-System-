package university.management.system;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.File;
import java.util.*;
import java.text.SimpleDateFormat;
public class Main {
    private static University uni = new University();
    private static User currentUser = null;

    public static void main(String[] args) {
        applyTheme();
        try {
            DatabaseManager.initDatabase();
            DatabaseManager.loadAll(uni);
            if (uni.getCourses().isEmpty() && uni.getUsers().isEmpty()) {
                FileManager.loadAll(uni);
                DatabaseManager.saveAll(uni);
            }
        } catch (Exception ex) {
            System.out.println("DB load failed, falling back to FileManager: " + ex.getMessage());
            FileManager.loadAll(uni);
            try {
                DatabaseManager.saveAll(uni);
            } catch (Exception ignore) {}
        }
        boolean hasAdmin = false;
        for (int i = 0; i < uni.getUsers().size(); i++) {
            if (uni.getUsers().get(i).getRole().equals("SystemAdmin")) hasAdmin = true;
        }
        if (!hasAdmin) {
            String salt = PasswordUtil.generateSalt();
            String hash = PasswordUtil.hashPassword("admin123", salt);
            SystemAdmin sa = new SystemAdmin("A01", "Sys Admin", "admin", hash, salt, "sysadmin@uni.edu", "high");
            uni.addSystemAdmin(sa);
            FileManager.saveAll(uni);
            try { DatabaseManager.saveAll(uni); } catch (Exception ignore) {}
        }
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                showLoginScreen();
            }
        });
    }
    private static void applyTheme() {
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception ignored) {}

        Color primary = new Color(12, 61, 92);
        Color accent  = new Color(102, 204, 255);
        Color softBg  = new Color(245, 245, 255);
        Color buttonBg = new Color(255, 192, 203);

        UIManager.put("Panel.background", softBg);
        UIManager.put("Table.background", Color.WHITE);
        UIManager.put("Table.gridColor", new Color(220, 220, 230));
        UIManager.put("Table.selectionBackground", accent);
        UIManager.put("Table.selectionForeground", Color.BLACK);
        UIManager.put("Button.background", buttonBg);
        UIManager.put("Button.foreground", Color.BLACK);
        UIManager.put("Label.foreground", primary);
        UIManager.put("ToolTip.background", new Color(255, 255, 225));
        UIManager.put("TitledBorder.titleColor", primary);
        Font base = UIManager.getFont("Label.font");
        if (base == null) base = new Font("SansSerif", Font.PLAIN, 12);
        Font uiFont = base.deriveFont(Font.PLAIN, 13f);
        UIManager.put("Label.font", uiFont);
        UIManager.put("Button.font", uiFont.deriveFont(Font.BOLD));
        UIManager.put("Table.font", uiFont);
        UIManager.put("TableHeader.font", uiFont.deriveFont(Font.BOLD));
    }
    private static void showLoginScreen() {
        JFrame loginFrame = new JFrame("University Management System - Login");
        loginFrame.setSize(520, 360);
        loginFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        loginFrame.setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(245, 245, 255));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8,8,8,8);

        JLabel title = new JLabel("Welcome to Alamein University");
        title.setFont(new Font("Arial", Font.BOLD, 18));
        title.setForeground(new Color(12, 61, 92));
        gbc.gridx=0; gbc.gridy=0; gbc.gridwidth=2;
        panel.add(title, gbc);

        gbc.gridwidth=1;
        gbc.gridx=0; gbc.gridy=1; panel.add(new JLabel("Username:"), gbc);
        JTextField userField = new JTextField(18);
        gbc.gridx=1; gbc.gridy=1; panel.add(userField, gbc);

        gbc.gridx=0; gbc.gridy=2; panel.add(new JLabel("Password:"), gbc);
        JPasswordField passField = new JPasswordField(18);
        gbc.gridx=1; gbc.gridy=2; panel.add(passField, gbc);

        JButton loginBtn = new JButton("Login");
        loginBtn.setBackground(new Color(102,204,255));
        gbc.gridx=0; gbc.gridy=3; panel.add(loginBtn, gbc);

        JButton registerBtn = new JButton("Register (Student)");
        registerBtn.setBackground(new Color(255,192,203));
        gbc.gridx=1; gbc.gridy=3; panel.add(registerBtn, gbc);

        loginFrame.add(panel);
        loginFrame.setVisible(true);

        loginBtn.addActionListener(e -> {
            String username = userField.getText().trim();
            String password = new String(passField.getPassword()).trim();
            if (password.length() < 6) {
                UIUtils.showError(loginFrame, "Password must contain at least 6 characters");
                return;
            }
            User u = uni.authenticate(username, password);
            if (u == null) {
                UIUtils.showError(loginFrame, "Invalid credentials");
            } else {
                currentUser = u;
                UIUtils.showInfo(loginFrame, "Welcome " + u.getName() + " (" + u.getRole() + ")");
                loginFrame.dispose();
                showDashboard();
            }
        });

        registerBtn.addActionListener(e -> showStudentRegistration(loginFrame));
    }
    private static void showStudentRegistration(JFrame parent) {
        JTextField idField = new JTextField();
        JTextField nameField = new JTextField();
        JTextField usernameField = new JTextField();
        JPasswordField passField = new JPasswordField();
        JTextField emailField = new JTextField();
        JTextField admissionField = new JTextField("2025-01-01");
        String[] statusOptions = {"Active", "On Probation", "Graduated"};
        JComboBox<String> statusBox = new JComboBox<String>(statusOptions);

        idField.setInputVerifier(new NonEmptyVerifier("Student ID"));
        nameField.setInputVerifier(new NonEmptyVerifier("Full name"));
        usernameField.setInputVerifier(new NonEmptyVerifier("Username"));
        passField.setInputVerifier(new PasswordVerifier(6));
        emailField.setInputVerifier(new NonEmptyVerifier("Email"));

        Object[] message = {
                "Student ID:", idField,
                "Full Name:", nameField,
                "Username:", usernameField,
                "Password (min 6):", passField,
                "Email:", emailField,
                "Admission Date:", admissionField,
                "Academic Status:", statusBox
        };

        int option = JOptionPane.showConfirmDialog(parent, message, "Register Student", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            if (!idField.getInputVerifier().verify(idField) ||
                    !nameField.getInputVerifier().verify(nameField) ||
                    !usernameField.getInputVerifier().verify(usernameField) ||
                    !passField.getInputVerifier().verify(passField) ||
                    !emailField.getInputVerifier().verify(emailField)) {
                UIUtils.showError(parent, "Please fix validation errors before submitting.");
                return;
            }
            String id = idField.getText().trim();
            String name = nameField.getText().trim();
            String username = usernameField.getText().trim();
            String password = new String(passField.getPassword()).trim();
            String email = emailField.getText().trim();
            String admission = admissionField.getText().trim();
            String status = (String) statusBox.getSelectedItem();

            for (int i = 0; i < uni.getUsers().size(); i++) {
                if (uni.getUsers().get(i).getUsername().equals(username)) {
                    UIUtils.showError(parent, "Username already exists");
                    return;
                }
            }

            String salt = PasswordUtil.generateSalt();
            String hash = PasswordUtil.hashPassword(password, salt);
            Student s = new Student(id, name, username, hash, salt, email, admission, status);
            uni.addStudent(s);
            FileManager.saveAll(uni);
            try { DatabaseManager.saveAll(uni); } catch (Exception ignore) {}
            UIUtils.showInfo(parent, "Student registered. You can now login.");
        }
    }
    private static void showDashboard() {
        JFrame frame = new JFrame("Dashboard - " + currentUser.getRole());
        frame.setSize(1000, 650);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(new Color(46,134,193));
        header.setPreferredSize(new Dimension(1000, 64));
        JLabel title = new JLabel("University Management System");
        title.setForeground(Color.white);
        title.setFont(new Font("Arial", Font.BOLD, 20));
        header.add(title, BorderLayout.CENTER);

        JPanel side = new JPanel();
        side.setLayout(new GridLayout(12,1,8,8));
        side.setBackground(new Color(240,248,255));
        side.setPreferredSize(new Dimension(240,0));

        JButton btnProfile = new JButton("Profile");
        JButton btnEntities = new JButton("Entities");
        JButton btnCourses = new JButton("Courses");
        JButton btnEnroll = new JButton("Enroll/Withdraw");
        JButton btnReports = new JButton("Reports");
        JButton btnSave = new JButton("Save Data");
        JButton btnLogout = new JButton("Logout");
        JButton btnUsers = new JButton("Users");
        JButton btnEnrollments = new JButton("All Enrollments");

        side.add(btnProfile);
        side.add(btnEntities);
        side.add(btnCourses);
        side.add(btnEnroll);
        side.add(btnEnrollments);
        side.add(btnReports);
        side.add(btnUsers);
        side.add(btnSave);
        side.add(btnLogout);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(new Color(250,250,250));

        JTextArea welcome = new JTextArea("Welcome " + currentUser.getName() + " (" + currentUser.getRole() + ")\n\nUse the menu to perform actions.");
        welcome.setEditable(false);
        welcome.setFont(new Font("Monospaced", Font.PLAIN, 14));
        mainPanel.add(new JScrollPane(welcome), BorderLayout.CENTER);

        frame.add(header, BorderLayout.NORTH);
        frame.add(side, BorderLayout.WEST);
        frame.add(mainPanel, BorderLayout.CENTER);

        frame.setVisible(true);

        btnProfile.addActionListener(e -> showProfile(mainPanel));
        btnEntities.addActionListener(e -> {
            if (currentUser.getRole().equals("Student")) showStudentEntities(mainPanel);
            else if (currentUser.getRole().equals("Faculty")) showFacultyEntities(mainPanel);
            else if (currentUser.getRole().equals("AdminStaff") || currentUser.getRole().equals("SystemAdmin")) showAdminEntities(mainPanel);
            else UIUtils.showError(frame, "Unknown role");
        });
        btnCourses.addActionListener(e -> showCoursesPanel(mainPanel));
        btnEnroll.addActionListener(e -> showEnrollmentPanel(mainPanel));
        btnEnrollments.addActionListener(e -> showEnrollmentsTable(mainPanel));
        btnReports.addActionListener(e -> showReportsPanel(mainPanel));
        btnUsers.addActionListener(e -> showUsersTable(mainPanel));
        btnSave.addActionListener(e -> {
            FileManager.saveAll(uni);
            try { DatabaseManager.saveAll(uni); } catch (Exception ex) {}
            UIUtils.showInfo(frame, "Data saved to files and DB.");
        });
        btnLogout.addActionListener(e -> {
            currentUser = null;
            frame.dispose();
            FileManager.saveAll(uni);
            try { DatabaseManager.saveAll(uni); } catch (Exception ex) {}
            showLoginScreen();
        });
    }
    private static void showProfile(JPanel parent) {
        parent.removeAll();
        JTextArea area = new JTextArea();
        area.setEditable(false);
        StringBuilder sb = new StringBuilder();
        sb.append("Profile:\n");
        sb.append("ID: ").append(currentUser.getId()).append("\n");
        sb.append("Name: ").append(currentUser.getName()).append("\n");
        sb.append("Username: ").append(currentUser.getUsername()).append("\n");
        sb.append("Email: ").append(currentUser.getEmail()).append("\n");
        sb.append("Role: ").append(currentUser.getRole()).append("\n");
        area.setText(sb.toString());

        JPanel p = new JPanel(new BorderLayout());
        p.add(new JScrollPane(area), BorderLayout.CENTER);
        JPanel bp = new JPanel();
        JButton editBtn = new JButton("Edit Profile");
        JButton pwdBtn = new JButton("Reset Password");
        bp.add(editBtn); bp.add(pwdBtn);
        p.add(bp, BorderLayout.SOUTH);
        parent.add(p, BorderLayout.CENTER);
        parent.revalidate(); parent.repaint();

        editBtn.addActionListener(e -> {
            String newName = JOptionPane.showInputDialog(parent, "Enter new name:", currentUser.getName());
            String newEmail = JOptionPane.showInputDialog(parent, "Enter new email:", currentUser.getEmail());
            if (newName != null && newEmail != null) {
                currentUser.setName(newName);
                currentUser.setEmail(newEmail);
                FileManager.saveAll(uni);
                try { DatabaseManager.saveAll(uni); } catch (Exception ignore) {}
                UIUtils.showInfo(parent, "Profile updated.");
                showProfile(parent);
            }
        });

        pwdBtn.addActionListener(e -> {
            String oldPwd = JOptionPane.showInputDialog(parent, "Enter current password:");
            if (oldPwd == null) return;
            if (!PasswordUtil.verifyPassword(oldPwd, currentUser.getSalt(), currentUser.getPasswordHash())) {
                UIUtils.showError(parent, "Incorrect current password");
                return;
            }
            String newPwd = JOptionPane.showInputDialog(parent, "Enter new password (min 6):");
            if (newPwd == null) return;
            if (newPwd.length() < 6) { UIUtils.showError(parent, "Password must be at least " + 6 + " characters"); return; }
            String salt = PasswordUtil.generateSalt();
            String hash = PasswordUtil.hashPassword(newPwd, salt);
            currentUser.setSalt(salt);
            currentUser.setPasswordHash(hash);
            FileManager.saveAll(uni);
            try { DatabaseManager.saveAll(uni); } catch (Exception ignore) {}
            UIUtils.showInfo(parent, "Password updated.");
        });
    }
    private static void showStudentEntities(JPanel parent) {
        parent.removeAll();
        JPanel p = new JPanel(new BorderLayout());
        Student s = (Student) currentUser;
        JTextArea area = new JTextArea();
        area.setEditable(false);
        StringBuilder sb = new StringBuilder();
        sb.append("Student: ").append(s.getName()).append("\n");
        sb.append("Admission: ").append(s.getAdmissionDate()).append("\n");
        sb.append("Academic Status: ").append(s.getAcademicStatus()).append("\n\n");
        sb.append("Enrolled Courses:\n");
        for (int i = 0; i < s.getEnrolledCourses().size(); i++) sb.append("- ").append(s.getEnrolledCourses().get(i)).append("\n");
        sb.append("\nGPA: ").append(String.format("%.2f", s.calculateGPA(uni))).append("\n");
        area.setText(sb.toString());

        JPanel btnp = new JPanel();
        JButton req = new JButton("Request Enrollment");
        JButton withdraw = new JButton("Withdraw from Course");
        btnp.add(req); btnp.add(withdraw);

        p.add(new JScrollPane(area), BorderLayout.CENTER);
        p.add(btnp, BorderLayout.SOUTH);
        parent.add(p, BorderLayout.CENTER);
        parent.revalidate(); parent.repaint();

        req.addActionListener(e -> {
            String courseCode = JOptionPane.showInputDialog(parent, "Enter course code to request enrollment (e.g., CS101):");
            if (courseCode == null || courseCode.trim().isEmpty()) return;
            String today = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
            String trimmed = courseCode.trim();
            for (int i = 0; i < uni.getEnrollments().size(); i++) {
                Enrollment en = uni.getEnrollments().get(i);
                if (en.getStudentId().equals(s.getId()) && en.getCourseCode() != null && en.getCourseCode().trim().equalsIgnoreCase(trimmed)) {
                    UIUtils.showError(parent, "You already have an enrollment record (status: " + en.getStatus() + ")");
                    return;
                }
            }
            Enrollment reqEnroll = new Enrollment(s.getId(), trimmed, today, -1.0, "Pending");
            uni.addEnrollment(reqEnroll);
            FileManager.saveAll(uni);
            try { DatabaseManager.saveAll(uni); } catch (Exception ignore) {}
            UIUtils.showInfo(parent, "Enrollment request submitted. An admin must approve it.");
            showStudentEntities(parent);
        });

        withdraw.addActionListener(e -> {
            String courseCode = JOptionPane.showInputDialog(parent, "Enter course code to withdraw:");
            if (courseCode == null || courseCode.trim().isEmpty()) return;
            boolean ok = uni.withdrawStudentFromCourse(s.getId(), courseCode.trim());
            FileManager.saveAll(uni);
            try { DatabaseManager.saveAll(uni); } catch (Exception ignore) {}
            UIUtils.showInfo(parent, ok ? "Withdrawn successfully" : "Withdraw failed");
            showStudentEntities(parent);
        });
    }
    private static void showFacultyEntities(JPanel parent) {
        parent.removeAll();
        Faculty f = (Faculty) currentUser;
        JPanel p = new JPanel(new BorderLayout());
        JTextArea area = new JTextArea();
        area.setEditable(false);

        StringBuilder sb = new StringBuilder();
        sb.append("Faculty: ").append(f.getName()).append("\nDepartment: ").append(f.getDepartment()).append("\n\nCourses you teach:\n");
        for (int i = 0; i < uni.getCourses().size(); i++) {
            Course c = uni.getCourses().get(i);
            if (f.getId().equals(c.getInstructorId())) sb.append("- ").append(c.getCode()).append(" : ").append(c.getTitle()).append("\n");
        }
        area.setText(sb.toString());

        JPanel btnp = new JPanel();
        JButton gradeBtn = new JButton("Assign Grade");
        JButton rosterBtn = new JButton("View Roster");
        btnp.add(rosterBtn); btnp.add(gradeBtn);

        p.add(new JScrollPane(area), BorderLayout.CENTER);
        p.add(btnp, BorderLayout.SOUTH);
        parent.add(p, BorderLayout.CENTER);
        parent.revalidate(); parent.repaint();

        rosterBtn.addActionListener(e -> {
            String courseCode = JOptionPane.showInputDialog(parent, "Enter course code to view roster:");
            if (courseCode == null || courseCode.trim().isEmpty()) return;
            StringBuilder r = new StringBuilder();
            r.append("Roster for ").append(courseCode).append(":\n");
            for (int i = 0; i < uni.getEnrollments().size(); i++) {
                Enrollment en = uni.getEnrollments().get(i);
                if (en.getCourseCode().equals(courseCode) && en.getStatus().equals("Registered")) {
                    Student st = uni.findStudentById(en.getStudentId());
                    if (st != null) r.append("- ").append(st.getId()).append(" ").append(st.getName()).append(" Grade: ").append(en.getGrade() >= 0 ? en.getGrade() : "N/A").append("\n");
                }
            }
            UIUtils.showInfo(parent, r.toString());
        });

        gradeBtn.addActionListener(e -> {
            String courseCode = JOptionPane.showInputDialog(parent, "Course code:");
            String studentId = JOptionPane.showInputDialog(parent, "Student ID:");
            String gradeStr = JOptionPane.showInputDialog(parent, "Grade (0-100):");
            if (courseCode == null || studentId == null || gradeStr == null) return;
            double grade;
            try { grade = Double.parseDouble(gradeStr); }
            catch (NumberFormatException ex) { UIUtils.showError(parent, "Grade must be a number"); return; }
            boolean found = false;
            for (int i = 0; i < uni.getEnrollments().size(); i++) {
                Enrollment en = uni.getEnrollments().get(i);
                if (en.getCourseCode().equals(courseCode) && en.getStudentId().equals(studentId) && en.getStatus().equals("Registered")) {
                    en.setGrade(grade);
                    en.setStatus("Completed");
                    found = true;
                    break;
                }
            }
            FileManager.saveAll(uni);
            try { DatabaseManager.saveAll(uni); } catch (Exception ignore) {}
            UIUtils.showInfo(parent, found ? "Grade assigned." : "Enrollment not found.");
        });
    }
    private static void showAdminEntities(JPanel parent) {
        parent.removeAll();
        JPanel p = new JPanel(new BorderLayout());
        JTextArea area = new JTextArea();
        area.setEditable(false);
        StringBuilder sb = new StringBuilder();
        sb.append("Admin Panel\n");
        sb.append("Users count: ").append(uni.getUsers().size()).append("\n");
        sb.append("Students: ").append(uni.getStudents().size()).append("\n");
        sb.append("Faculty: ").append(uni.getFaculties().size()).append("\n");
        sb.append("Courses: ").append(uni.getCourses().size()).append("\n");
        area.setText(sb.toString());

        JPanel btnp = new JPanel();
        JButton addCourse = new JButton("Create Course");
        JButton addFaculty = new JButton("Create Faculty");
        JButton addDepartment = new JButton("Create Department");
        JButton listAll = new JButton("List All Entities");
        JButton pending = new JButton("Pending Requests");
        btnp.add(addCourse); btnp.add(addFaculty); btnp.add(addDepartment); btnp.add(listAll); btnp.add(pending);

        p.add(new JScrollPane(area), BorderLayout.CENTER);
        p.add(btnp, BorderLayout.SOUTH);
        parent.add(p, BorderLayout.CENTER);
        parent.revalidate(); parent.repaint();

        addCourse.addActionListener(e -> createCourseDialog(parent));
        addFaculty.addActionListener(e -> createFacultyDialog(parent));
        addDepartment.addActionListener(e -> {
            String id = JOptionPane.showInputDialog(parent, "Department ID:");
            String name = JOptionPane.showInputDialog(parent, "Department Name:");
            if (id == null || id.trim().isEmpty() || name == null || name.trim().isEmpty()) { UIUtils.showError(parent, "Invalid input"); return; }
            Department d = new Department(id.trim(), name.trim());
            uni.addDepartment(d);
            FileManager.saveAll(uni);
            try { DatabaseManager.saveAll(uni); } catch (Exception ignore) {}
            UIUtils.showInfo(parent, "Department created.");
        });
        listAll.addActionListener(e -> {
            StringBuilder x = new StringBuilder();
            x.append("Students:\n");
            for (int i = 0; i < uni.getStudents().size(); i++) {
                Student s = uni.getStudents().get(i);
                x.append(s.getId()).append(" ").append(s.getName()).append("\n");
            }
            x.append("\nFaculty:\n");
            for (int i = 0; i < uni.getFaculties().size(); i++) {
                Faculty f = uni.getFaculties().get(i);
                x.append(f.getId()).append(" ").append(f.getName()).append("\n");
            }
            x.append("\nCourses:\n");
            for (int i = 0; i < uni.getCourses().size(); i++) {
                Course c = uni.getCourses().get(i);
                x.append(c.getCode()).append(" ").append(c.getTitle()).append(" Instructor: ").append(c.getInstructorId()).append("\n");
            }
            UIUtils.showInfo(parent, x.toString());
        });

        pending.addActionListener(e -> {
            StringBuilder out = new StringBuilder();
            out.append("Pending Enrollment Requests:\n");
            for (int i = 0; i < uni.getEnrollments().size(); i++) {
                Enrollment en = uni.getEnrollments().get(i);
                if ("Pending".equals(en.getStatus())) {
                    out.append(en.getStudentId()).append(" | ").append(en.getCourseCode()).append(" | ").append(en.getEnrollmentDate()).append("\n");
                }
            }
            String sel = JOptionPane.showInputDialog(parent, out.toString() + "\nEnter studentId|courseCode to approve (or cancel):");
            if (sel == null || sel.trim().isEmpty()) return;
            String[] parts = sel.split("\\|");
            if (parts.length != 2) { UIUtils.showError(parent, "Invalid input format. Use studentId|courseCode"); return; }
            String sid = parts[0].trim();
            String ccode = parts[1].trim();
            String date = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
            String msg = uni.registerStudentForCourse(sid, ccode, date); // convert pending -> registered if ok
            FileManager.saveAll(uni);
            try { DatabaseManager.saveAll(uni); } catch (Exception ignore) {}
            UIUtils.showInfo(parent, msg);
        });
    }
    private static void createCourseDialog(Component parent) {
        JTextField code = new JTextField();
        JTextField title = new JTextField();
        JTextField desc = new JTextField();
        JTextField credits = new JTextField("3");
        JTextField max = new JTextField("30");
        JTextField prereq = new JTextField();
        JTextField instr = new JTextField();
        JTextField sched = new JTextField();

        code.setInputVerifier(new NonEmptyVerifier("Course Code"));
        title.setInputVerifier(new NonEmptyVerifier("Title"));
        credits.setInputVerifier(new DoubleVerifier("Credit Hours"));
        max.setInputVerifier(new IntegerVerifier("Max Enrollment"));

        Object[] msg = {
                "Course Code:", code,
                "Title:", title,
                "Description:", desc,
                "Credit Hours:", credits,
                "Max Enrollment:", max,
                "Prerequisites (comma):", prereq,
                "Instructor ID (optional):", instr,
                "Schedule:", sched
        };
        int opt = JOptionPane.showConfirmDialog(null, msg, "Create Course", JOptionPane.OK_CANCEL_OPTION);
        if (opt == JOptionPane.OK_OPTION) {
            if (!code.getInputVerifier().verify(code) || !title.getInputVerifier().verify(title) || !credits.getInputVerifier().verify(credits) || !max.getInputVerifier().verify(max)) {
                UIUtils.showError(parent, "Please fix validation errors");
                return;
            }
            try {
                Course c = new Course(code.getText().trim(), title.getText().trim(), desc.getText().trim(), Double.parseDouble(credits.getText().trim()), prereq.getText().trim(), instr.getText().trim(), Integer.parseInt(max.getText().trim()), sched.getText().trim());
                boolean dbOk = true;
                try { dbOk = DatabaseManager.insertCourse(c); } catch (Exception ignore) {}
                uni.addCourse(c);
                FileManager.saveAll(uni);
                try { DatabaseManager.saveAll(uni); } catch (Exception ignore) {}
                UIUtils.showInfo(parent, "Course created." + (dbOk ? "" : " (DB insert failed)"));
            } catch (Exception ex) {
                UIUtils.showError(parent, "Invalid input: " + ex.getMessage());
            }
        }
    }

    private static void createFacultyDialog(Component parent) {
        String id = JOptionPane.showInputDialog(parent, "Faculty ID:");
        String name = JOptionPane.showInputDialog(parent, "Full name:");
        String username = JOptionPane.showInputDialog(parent, "Username:");
        String password = JOptionPane.showInputDialog(parent, "Password (min 6):");
        String email = JOptionPane.showInputDialog(parent, "Email:");
        String dept = JOptionPane.showInputDialog(parent, "Department:");
        String expertise = JOptionPane.showInputDialog(parent, "Expertise:");
        if (id == null || id.trim().isEmpty() || name == null || name.trim().isEmpty() || username == null || username.trim().isEmpty()) { UIUtils.showError(parent, "Required fields missing"); return; }
        if (password == null || password.length() < 6) { UIUtils.showError(parent, "Password must be at least 6 characters"); return; }
        String salt = PasswordUtil.generateSalt();
        String hash = PasswordUtil.hashPassword(password, salt);
        Faculty f = new Faculty(id.trim(), name.trim(), username.trim(), hash, salt, email == null ? "" : email.trim(), dept == null ? "" : dept.trim(), expertise == null ? "" : expertise.trim());
        uni.addFaculty(f);
        FileManager.saveAll(uni);
        try { DatabaseManager.saveAll(uni); } catch (Exception ignore) {}
        UIUtils.showInfo(parent, "Faculty created.");
    }
    private static void showCoursesPanel(JPanel parent) {
        parent.removeAll();
        String[] cols = {"Code","Title","Credits","Max","Instructor","Prerequisites","Schedule"};
        DefaultTableModel model = new DefaultTableModel(cols,0) {
            public boolean isCellEditable(int r,int c) { return false; }
        };
        for (int i = 0; i < uni.getCourses().size(); i++) {
            Course c = uni.getCourses().get(i);
            model.addRow(new Object[]{c.getCode(), c.getTitle(), c.getCreditHours(), c.getMaxEnrollment(), c.getInstructorId(), String.join(",", c.getPrerequisites()), c.getSchedule()});
        }
        JTable table = new JTable(model);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.getTableHeader().setBackground(new Color(12,61,92));
        table.getTableHeader().setForeground(Color.WHITE);

        JScrollPane sp = new JScrollPane(table);
        JPanel p = new JPanel(new BorderLayout());
        p.add(sp, BorderLayout.CENTER);

        JPanel controls = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton refresh = new JButton("Refresh");
        JButton btnEdit = new JButton("Edit Selected");
        JButton btnDelete = new JButton("Delete Selected");
        JButton btnExport = new JButton("Export CSV");
        JButton btnImport = new JButton("Import CSV");
        controls.add(refresh);
        controls.add(btnEdit);
        controls.add(btnDelete);
        controls.add(btnExport);
        controls.add(btnImport);

        p.add(controls, BorderLayout.SOUTH);
        parent.add(p, BorderLayout.CENTER);
        parent.revalidate(); parent.repaint();

        refresh.addActionListener(e -> {
            try {
                DatabaseManager.loadAll(uni);
            } catch (Exception ignore) {}
            showCoursesPanel(parent);
        });

        btnEdit.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row < 0) { UIUtils.showError(parent, "Select a course first"); return; }
            String code = String.valueOf(table.getValueAt(row, 0));
            Course c = uni.findCourseByCode(code);
            if (c == null) { UIUtils.showError(parent, "Course not found in model"); return; }

            JTextField title = new JTextField(c.getTitle());
            JTextArea desc = new JTextArea(c.getDescription(), 4, 30);
            JTextField credits = new JTextField(String.valueOf(c.getCreditHours()));
            JTextField max = new JTextField(String.valueOf(c.getMaxEnrollment()));
            JTextField prereq = new JTextField(String.join(",", c.getPrerequisites()));
            JTextField instr = new JTextField(c.getInstructorId());
            JTextField sched = new JTextField(c.getSchedule());

            JPanel form = new JPanel(new GridBagLayout());
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.insets = new Insets(4,4,4,4);
            gbc.fill = GridBagConstraints.HORIZONTAL;
            gbc.gridx=0; gbc.gridy=0; form.add(new JLabel("Title:"), gbc);
            gbc.gridx=1; form.add(title, gbc);
            gbc.gridx=0; gbc.gridy=1; form.add(new JLabel("Description:"), gbc);
            gbc.gridx=1; form.add(new JScrollPane(desc), gbc);
            gbc.gridx=0; gbc.gridy=2; form.add(new JLabel("Credit Hours:"), gbc);
            gbc.gridx=1; form.add(credits, gbc);
            gbc.gridx=0; gbc.gridy=3; form.add(new JLabel("Max Enrollment:"), gbc);
            gbc.gridx=1; form.add(max, gbc);
            gbc.gridx=0; gbc.gridy=4; form.add(new JLabel("Prerequisites (comma):"), gbc);
            gbc.gridx=1; form.add(prereq, gbc);
            gbc.gridx=0; gbc.gridy=5; form.add(new JLabel("Instructor ID:"), gbc);
            gbc.gridx=1; form.add(instr, gbc);
            gbc.gridx=0; gbc.gridy=6; form.add(new JLabel("Schedule:"), gbc);
            gbc.gridx=1; form.add(sched, gbc);

            int opt = JOptionPane.showConfirmDialog(parent, form, "Edit Course " + c.getCode(), JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
            if (opt == JOptionPane.OK_OPTION) {
                try {
                    Course updated = new Course(
                            c.getCode(),
                            title.getText().trim(),
                            desc.getText().trim(),
                            Double.parseDouble(credits.getText().trim()),
                            prereq.getText().trim(),
                            instr.getText().trim(),
                            Integer.parseInt(max.getText().trim()),
                            sched.getText().trim()
                    );

                    boolean dbOk = false;
                    try { dbOk = DatabaseManager.updateCourse(updated); } catch (Exception ignore) {}

                    boolean modelOk = updateCourseInMemory(updated);

                    FileManager.saveAll(uni);
                    try { DatabaseManager.saveAll(uni); } catch (Exception ignore) {}

                    if (dbOk && modelOk) {
                        UIUtils.showInfo(parent, "Course updated successfully");
                    } else if (dbOk) {
                        UIUtils.showInfo(parent, "Database updated, but model update had issues. Reloading model.");
                        try { DatabaseManager.loadAll(uni); } catch (Exception ignore) {}
                        FileManager.saveAll(uni);
                    } else if (modelOk) {
                        UIUtils.showInfo(parent, "Model updated but DB update failed.");
                    } else {
                        UIUtils.showError(parent, "Failed to update course (DB and model).");
                    }
                    showCoursesPanel(parent);
                } catch (Exception ex) {
                    UIUtils.showError(parent, "Invalid input: " + ex.getMessage());
                }
            }
        });

        btnDelete.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row < 0) { UIUtils.showError(parent, "Select a course first"); return; }
            String code = String.valueOf(table.getValueAt(row, 0));
            int confirm = JOptionPane.showConfirmDialog(parent, "Delete course " + code + " ? This will remove enrollments referencing it.", "Confirm Delete", JOptionPane.YES_NO_OPTION);
            if (confirm != JOptionPane.YES_OPTION) return;

            boolean dbOk = false;
            try { dbOk = DatabaseManager.deleteCourse(code); } catch (Exception ignore) {}

            boolean modelOk = deleteCourseInMemory(code);

            FileManager.saveAll(uni);
            try { DatabaseManager.saveAll(uni); } catch (Exception ignore) {}

            if (dbOk && modelOk) {
                UIUtils.showInfo(parent, "Course deleted.");
            } else if (dbOk) {
                UIUtils.showInfo(parent, "Deleted in DB, but model had trouble - reloading model.");
                try { DatabaseManager.loadAll(uni); } catch (Exception ignore) {}
                FileManager.saveAll(uni);
            } else if (modelOk) {
                UIUtils.showInfo(parent, "Removed from model but DB delete failed.");
            } else {
                UIUtils.showError(parent, "Delete failed (DB and model).");
            }
            showCoursesPanel(parent);
        });

        btnExport.addActionListener(e -> {
            JFileChooser fc = new JFileChooser();
            fc.setDialogTitle("Save courses to CSV");
            int rv = fc.showSaveDialog(parent);
            if (rv == JFileChooser.APPROVE_OPTION) {
                File file = fc.getSelectedFile();
                boolean ok = false;
                try { ok = DatabaseManager.exportCoursesToCSV(file.getAbsolutePath()); } catch (Exception ex) { ok = false; System.out.println("Export error: " + ex.getMessage()); }
                UIUtils.showInfo(parent, ok ? "Exported to " + file.getAbsolutePath() : "Export failed");
            }
        });

        btnImport.addActionListener(e -> {
            JFileChooser fc = new JFileChooser();
            fc.setDialogTitle("Import courses from CSV");
            int rv = fc.showOpenDialog(parent);
            if (rv == JFileChooser.APPROVE_OPTION) {
                File file = fc.getSelectedFile();
                String[] options = {"Skip existing", "Overwrite existing"};
                int sel = JOptionPane.showOptionDialog(parent, "Choose import mode", "Import Mode", JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
                boolean overwrite = sel == 1;
                boolean ok = false;
                try { ok = DatabaseManager.importCoursesFromCSV(file.getAbsolutePath(), overwrite); } catch (Exception ex) { ok = false; System.out.println("Import error: " + ex.getMessage()); }
                if (ok) {
                    try { DatabaseManager.loadAll(uni); } catch (Exception ignore) {}
                    FileManager.saveAll(uni);
                    UIUtils.showInfo(parent, "Import completed.");
                    showCoursesPanel(parent);
                } else {
                    UIUtils.showError(parent, "Import failed. Check console for errors.");
                }
            }
        });
    }
    private static void showEnrollmentsTable(JPanel parent) {
        parent.removeAll();
        String[] cols = {"StudentId","Course","Date","Status","Grade"};
        DefaultTableModel model = new DefaultTableModel(cols,0) {
            public boolean isCellEditable(int r,int c) { return false; }
        };
        for (int i = 0; i < uni.getEnrollments().size(); i++) {
            Enrollment e = uni.getEnrollments().get(i);
            model.addRow(new Object[]{e.getStudentId(), e.getCourseCode(), e.getEnrollmentDate(), e.getStatus(), e.getGrade() >= 0 ? e.getGrade() : "N/A"});
        }
        JTable table = new JTable(model);
        JPanel p = new JPanel(new BorderLayout());
        p.add(new JScrollPane(table), BorderLayout.CENTER);
        JButton refresh = new JButton("Refresh");
        refresh.addActionListener(e -> showEnrollmentsTable(parent));
        p.add(refresh, BorderLayout.SOUTH);
        parent.add(p, BorderLayout.CENTER);
        parent.revalidate(); parent.repaint();
    }
    private static void showEnrollmentPanel(JPanel parent) {
        parent.removeAll();
        JPanel p = new JPanel(new BorderLayout());
        StringBuilder sb = new StringBuilder();
        sb.append("Enrollments (see table for details). Use Admin pending/Manual Enroll to approve.\n");
        JTextArea area = new JTextArea(sb.toString());
        area.setEditable(false);

        JButton assign = new JButton("Assign Grade");
        JButton manualEnroll = new JButton("Manual Enroll");

        String role = currentUser.getRole();
        boolean isStudent = "Student".equals(role);
        boolean isFaculty = "Faculty".equals(role);
        boolean isAdmin = "AdminStaff".equals(role) || "SystemAdmin".equals(role);

        JPanel btnp = new JPanel();
        if (isAdmin) { btnp.add(manualEnroll); btnp.add(assign); }
        else if (isFaculty) { btnp.add(assign); }

        p.add(area, BorderLayout.NORTH);
        p.add(btnp, BorderLayout.SOUTH);

        parent.add(p, BorderLayout.CENTER);
        parent.revalidate(); parent.repaint();

        manualEnroll.addActionListener(e -> {
            String sid = JOptionPane.showInputDialog(parent, "Student ID:");
            String course = JOptionPane.showInputDialog(parent, "Course Code:");
            String date = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
            String msg = uni.registerStudentForCourse(sid, course, date);
            FileManager.saveAll(uni);
            try { DatabaseManager.saveAll(uni); } catch (Exception ignore) {}
            UIUtils.showInfo(parent, msg);
            showEnrollmentPanel(parent);
        });

        assign.addActionListener(e -> {
            String sid = JOptionPane.showInputDialog(parent, "Student ID:");
            String course = JOptionPane.showInputDialog(parent, "Course Code:");
            String gradeS = JOptionPane.showInputDialog(parent, "Grade:");
            if (sid == null || course == null || gradeS == null) return;
            double g;
            try { g = Double.parseDouble(gradeS); } catch (NumberFormatException ex) { UIUtils.showError(parent, "Invalid grade"); return; }
            boolean updated = false;
            for (int i = 0; i < uni.getEnrollments().size(); i++) {
                Enrollment en = uni.getEnrollments().get(i);
                if (en.getStudentId().equals(sid) && en.getCourseCode().equals(course) && en.getStatus().equals("Registered")) {
                    en.setGrade(g);
                    en.setStatus("Completed");
                    updated = true;
                    break;
                }
            }
            FileManager.saveAll(uni);
            try { DatabaseManager.saveAll(uni); } catch (Exception ignore) {}
            UIUtils.showInfo(parent, updated ? "Grade assigned" : "Enrollment not found");
        });
    }
    private static void showUsersTable(JPanel parent) {
        parent.removeAll();
        String[] cols = {"ID","Role","Username","Name","Email"};
        DefaultTableModel model = new DefaultTableModel(cols,0) {
            public boolean isCellEditable(int r,int c) { return false; }
        };
        for (int i = 0; i < uni.getUsers().size(); i++) {
            User u = uni.getUsers().get(i);
            model.addRow(new Object[]{u.getId(), u.getRole(), u.getUsername(), u.getName(), u.getEmail()});
        }
        JTable table = new JTable(model);
        JPanel p = new JPanel(new BorderLayout());
        p.add(new JScrollPane(table), BorderLayout.CENTER);
        JButton refresh = new JButton("Refresh");
        refresh.addActionListener(e -> showUsersTable(parent));
        p.add(refresh, BorderLayout.SOUTH);
        parent.add(p, BorderLayout.CENTER);
        parent.revalidate(); parent.repaint();
    }
    private static void showReportsPanel(JPanel parent) {
        parent.removeAll();
        JPanel p = new JPanel(new BorderLayout());
        JTextArea area = new JTextArea();
        area.setEditable(false);
        StringBuilder sb = new StringBuilder();
        sb.append("Reports Menu\n\n");
        sb.append("1) Students per Course\n");
        sb.append("2) Courses per Faculty\n");
        sb.append("3) Department summary\n");
        area.setText(sb.toString());
        p.add(new JScrollPane(area), BorderLayout.CENTER);
        JPanel btnp = new JPanel();
        JButton r1 = new JButton("Students per Course");
        JButton r2 = new JButton("Courses per Faculty");
        JButton r3 = new JButton("Department Summary");
        btnp.add(r1); btnp.add(r2); btnp.add(r3);
        p.add(btnp, BorderLayout.SOUTH);
        parent.add(p, BorderLayout.CENTER);
        parent.revalidate(); parent.repaint();

        r1.addActionListener(e -> {
            String course = JOptionPane.showInputDialog(parent, "Course code:");
            if (course == null) return;
            StringBuilder out = new StringBuilder();
            out.append("Students in ").append(course).append(":\n");
            for (int i = 0; i < uni.getEnrollments().size(); i++) {
                Enrollment en = uni.getEnrollments().get(i);
                if (en.getCourseCode().equals(course) && en.getStatus().equals("Registered")) {
                    Student s = uni.findStudentById(en.getStudentId());
                    if (s != null) out.append(s.getId()).append(" ").append(s.getName()).append("\n");
                }
            }
            UIUtils.showInfo(parent, out.toString());
        });

        r2.addActionListener(e -> {
            String facultyId = JOptionPane.showInputDialog(parent, "Faculty ID:");
            if (facultyId == null) return;
            StringBuilder out = new StringBuilder();
            out.append("Courses taught by ").append(facultyId).append(":\n");
            for (int i = 0; i < uni.getCourses().size(); i++) {
                Course c = uni.getCourses().get(i);
                if (facultyId.equals(c.getInstructorId())) out.append(c.getCode()).append(" ").append(c.getTitle()).append("\n");
            }
            UIUtils.showInfo(parent, out.toString());
        });

        r3.addActionListener(e -> {
            StringBuilder out = new StringBuilder();
            for (int i = 0; i < uni.getDepartments().size(); i++) {
                Department d = uni.getDepartments().get(i);
                out.append("Dept ").append(d.getId()).append(" - ").append(d.getName()).append("\n");
                out.append(" Faculty: ").append(String.join(",", d.getFacultyIds())).append("\n");
                out.append(" Courses: ").append(String.join(",", d.getOfferedCourses())).append("\n\n");
            }
            UIUtils.showInfo(parent, out.toString());
        });
    }
    private static boolean updateCourseInMemory(Course updated) {
        if (updated == null || updated.getCode() == null) return false;
        for (int i = 0; i < uni.getCourses().size(); i++) {
            Course c = uni.getCourses().get(i);
            if (updated.getCode().equals(c.getCode())) {
                uni.getCourses().set(i, updated);
                return true;
            }
        }
        return false;
    }

    private static boolean deleteCourseInMemory(String code) {
        if (code == null)
            return false;
        boolean removed = false;
        Iterator<Course> cit = uni.getCourses().iterator();
        while (cit.hasNext()) {
            Course c = cit.next();
            if (code.equals(c.getCode())) {
                cit.remove();
                removed = true;
                break;
            }
        }
        Iterator<Enrollment> eit = uni.getEnrollments().iterator();
        while (eit.hasNext()) {
            Enrollment e = eit.next();
            if (code.equals(e.getCourseCode())) {
                eit.remove();
            }
        }
        for (Department d : uni.getDepartments()) {
            try {
                d.getOfferedCourses().removeIf(cc -> code.equals(cc));
            } catch (Exception ignore) {
            }
        }
        return removed;
    }
    static class NonEmptyVerifier extends InputVerifier {
        private String fieldName;
        NonEmptyVerifier(String fieldName) {
            this.fieldName = fieldName;
        }
        public boolean verify(JComponent input) {
            String s = null;
            if (input instanceof JTextField) s = ((JTextField)input).getText();
            else if (input instanceof JPasswordField) s = new String(((JPasswordField)input).getPassword());
            if (s == null || s.trim().isEmpty()) {
                UIUtils.showError(input, fieldName + " cannot be empty");
                return false;
            }
            return true;
        }
    }

    static class IntegerVerifier extends InputVerifier {
        private String fieldName;
        IntegerVerifier(String fieldName) {
            this.fieldName = fieldName;
        }
        public boolean verify(JComponent input) {
            String s = ((JTextField)input).getText();
            try { Integer.parseInt(s.trim());
                return true;
            } catch (Exception ex) { UIUtils.showError(input, fieldName + " must be an integer");
                return false;
            }
        }
    }

    static class DoubleVerifier extends InputVerifier {
        private String fieldName;
        DoubleVerifier(String fieldName) {
            this.fieldName = fieldName;
        }
        public boolean verify(JComponent input) {
            String s = ((JTextField)input).getText();
            try { Double.parseDouble(s.trim());
                return true;
            } catch (Exception ex) {
                UIUtils.showError(input, fieldName + " must be a number");
                return false; }
        }
    }
    static class PasswordVerifier extends InputVerifier {
        private int min;
        PasswordVerifier(int min) {
            this.min = min;
        }
        public boolean verify(JComponent input) {
            String s = new String(((JPasswordField)input).getPassword());
            if (s.length() < min) {
                UIUtils.showError(input, "Password must be at least " + min + " characters");
                return false;
            }
            return true;
        }
    }
}