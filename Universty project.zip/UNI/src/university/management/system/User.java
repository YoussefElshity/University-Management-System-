package university.management.system;

public abstract class User {
    protected String id;
    protected String name;
    protected String username;
    protected String passwordHash;
    protected String salt;
    protected String email;
    public User(String id, String name, String username, String passwordHash, String salt, String email) {
        this.id = id;
        this.name = name;
        this.username = username;
        this.passwordHash = passwordHash;
        this.salt = salt;
        this.email = email;
    }

    public String getId() {
        return id;
    }
    public String getName() {
        return name;
    }
    public String getUsername() {
        return username;
    }
    public String getPasswordHash() {
        return passwordHash;
    }
    public String getSalt() {
        return salt;
    }
    public String getEmail() {
        return email;
    }

    public void setName(String name) {
        this.name = name;
    }
    public void setPasswordHash(String passwordHash) {
        this.passwordHash = passwordHash;
    }
    public void setSalt(String salt) {
        this.salt = salt;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public abstract String getRole();
}